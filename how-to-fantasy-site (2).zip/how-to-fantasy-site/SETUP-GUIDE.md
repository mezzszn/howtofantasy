# How to Fantasy: put it online with accounts

You need no GitHub and no coding. Three steps, about 15 minutes.

This folder has:
- `index.html`: the whole site, already pointed at your Supabase project.
- `manifest.webmanifest`, `sw.js` and the `icon-*.png` files: these make it installable. Upload them with `index.html`.
- `setup.sql`: creates the table that stores each person's saved data.

## Step 1. Create the table (2 minutes)
1. Open your Supabase project, then **SQL Editor** in the left menu, then **New query**.
2. Open `setup.sql`, copy everything, paste it in, and press **Run**. It should say "Success".
3. Open **Table Editor**. You should see a table named `user_data`.

## Step 2. Put the site online (5 minutes, free)
Pick one:
- **Netlify Drop** (easiest): go to https://app.netlify.com/drop, sign up, and drag this whole folder onto the page. You get a link like `https://something.netlify.app`. In Site settings you can rename it.
- **Cloudflare Pages**: Workers & Pages, Create, Pages, **Upload assets**, drag the folder.

Open the link and check the site loads. Later, if you buy a domain, both services let you attach it in Domain settings.

## Step 3. Tell Supabase your site address (3 minutes)
Without this, confirmation and password-reset emails send people to the wrong place.
1. In Supabase go to **Authentication**, then **URL Configuration**.
2. Set **Site URL** to your site link (for example `https://something.netlify.app`).
3. Under **Redirect URLs**, add the same link, then **Save**.

## Test it
1. Open your site, then the menu, then **Sign in**, then **Create an account**.
2. Supabase emails a confirmation link. Open it and you land back on the site, signed in.
3. Change a setting (for example your favorite team). Open the site on your phone, sign in, and the change is there.

## Using GitHub Pages instead of Netlify
1. On github.com click **New repository**, name it (for example `howtofantasy`), set it to **Public**, and create it.
2. Click **uploading an existing file** and drag in the files from inside the unzipped folder (`index.html` must be at the top level). Click **Commit changes**.
3. Open **Settings**, then **Pages**. Set Source to **Deploy from a branch**, choose **main** and **/ (root)**, and Save.
4. After a minute or two your site is at `https://YOURUSERNAME.github.io/howtofantasy/`.
5. In Supabase, Authentication, then URL Configuration: set Site URL to that address (with the `/howtofantasy/` part) and add `https://YOURUSERNAME.github.io/**` under Redirect URLs.
To update the site later, open the repository, choose Add file, then Upload files, and upload the changed files.

## Install it as an app on your phone
The site is an installable app (a "PWA"). After it is online on its https address:
- **iPhone:** open the link in **Safari**, tap the Share button, then **Add to Home Screen**.
- **Android:** open it in Chrome, tap the menu, then **Install app**. Settings in the site also has an Install button.

It then opens full screen with its own icon and keeps working with the last data it loaded if you lose signal. Updates arrive automatically the next time you open it with a connection.
This only works from the hosted https address, not from the file on your computer.

Real App Store or Google Play apps are possible later by wrapping this same site (Capacitor), but they cost $99 a year for Apple and $25 once for Google, need review, and aren't needed for a class project.

## Good to know
- **Email limits:** Supabase's built-in email sender allows only a few emails per hour. Fine for testing. For real users, add your own email service under Authentication, then SMTP Settings (Resend and Brevo have free plans).
- **Confirmation emails:** to skip the email step while testing, turn off **Confirm email** under Authentication, then Sign In / Providers, then Email. Turn it back on before real use.
- **Free plan:** Supabase pauses free projects after about a week with no use. Open the dashboard and click Restore if that happens.
- **Frozen data:** the injury, matchup and weather numbers in this site are a snapshot from when it was built. They do not refresh on their own. Automatic refreshing is the next project.
- **Passwords:** handled by Supabase and stored hashed. Never paste the `service_role` key anywhere. The key in `index.html` is the public one and is safe there.
- **Deleting a user:** Authentication, then Users, then the three dots, then Delete. Their saved data is removed with them.
